"""Пример: привязки колонок legacy ФормаСписка/ФормаВыбора (#103, #105, #107).

Скрипт разбирает существующую директорию формы из выгрузки v8unpack и
показывает колонки TabularField, извлечённые безопасным fallback #103.
Если форма не проиндексирована, печатается причина из
`classify_unindexed_form()` (#105). Исходные файлы не изменяются.

Источник колонки виден в поле `source`:

* `legacy_list_form_json` — UUID-привязка из блока 20 либо Pattern-ссылка
  `["#", UUID]` (#107);
* `legacy_list_form_bsl` — имя взято из `Колонки.Добавить` в модуле формы.

Запуск:

    python examples/legacy_list_form_bindings.py \
      /path/to/Object/ObjectForm/ФормаСписка

Для JSON-вывода:

    python examples/legacy_list_form_bindings.py FORM_DIR --json

Чтобы ссылка на форму печаталась относительно корня выгрузки:

    python examples/legacy_list_form_bindings.py FORM_DIR \
      --export-root /path/to/cf_export

Требуемые данные: скрипт работает только на реальной выгрузке v8unpack и
требует обязательного позиционного ``FORM_DIR``. Без выгрузки запуск
невозможен: вызов без аргументов штатно завершается ошибкой argparse.
Это ожидаемое поведение, а не дефект.

Статус: historical (#252). Файл сохранён как исторический пример: он
документирует layout legacy `ФормаСписка` / `ФормаВыбора` и связку
`source` -> `data_path`, полученную безопасным fallback #103 и #107 на
реальной выгрузке. Актуальная замена для диагностики неиндексируемых
форм — `examples/unindexed_forms_report.py`: он самодостаточен, даёт
RC=0 без аргументов и покрывает шесть категорий `UnindexedReason`.
Контракт элемента `TabularFieldColumn` описан в `docs/elem_parser.md`.
В автоматический регрессионный прогон файл не входит.

Категория: пример на реальной выгрузке.
Входные данные: FORM_DIR — каталог формы из выгрузки v8unpack.
Ожидаемый результат: обезличенный агрегат в stdout; коды возврата —
RC=0, если форма проиндексирована (elem_index_ok=True);
RC=1, если elem_index_ok=False — это штатный признак
неиндексируемой формы, агрегат и диагностика причины #105
печатаются как обычно, ошибкой запуска RC=1 не является;
RC=2 при ошибке argparse (см. «Поведение без данных»).
Локальные имена и CSV не публикуются и не коммитятся.
Абсолютные пути в выводе не печатаются (#262): ссылка на форму
выводится относительно ``--export-root``, без флага — как имя
каталога формы; абсолютный путь вычищается и из ``unindexed_detail``.
Поведение без данных: штатная ошибка argparse (RC=2) —
это ожидаемое поведение, а не дефект; в автоматический
прогон файл не входит.
"""
from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from v8unpack_agent.elem_parser import classify_unindexed_form, parse_elem_json

EXPECTED_SOURCES = {"legacy_list_form_json", "legacy_list_form_bsl"}
EXPECTED_TYPE = "TabularFieldColumn"


def _legacy_list_columns(elements: Sequence[dict[str, Any]]) -> list[dict[str, Any]]:
    """Вернуть только колонки, подтверждённые fallback #103."""
    return [
        element
        for element in elements
        if element.get("type") == EXPECTED_TYPE
        or element.get("source") in EXPECTED_SOURCES
    ]


def _form_ref(form_dir: Path, root: Path | None) -> str:
    """Ссылка на форму для печати.

    Если корень выгрузки известен, печатается относительный POSIX-путь.
    Иначе печатается только имя каталога формы: абсолютные пути в stdout
    недопустимы (#251, #262).
    """
    if root is not None:
        try:
            return form_dir.relative_to(root).as_posix()
        except ValueError:
            return form_dir.name
    return form_dir.name


def _sanitize_detail(detail: str, form_dir: Path, form_ref: str) -> str:
    """Заменить абсолютный путь формы в тексте детали на относительный.

    Текст детали формирует ``classify_unindexed_form()`` из production-кода,
    поэтому подстановка выполняется здесь и только по известному
    ``form_dir`` — без регулярных выражений по произвольному тексту.
    """
    for variant in (str(form_dir), form_dir.as_posix()):
        detail = detail.replace(variant, form_ref)
    return detail


def _build_report(form_dir: Path, root: Path | None = None) -> dict[str, Any]:
    form_ref = _form_ref(form_dir, root)
    result = parse_elem_json(form_dir)
    columns = _legacy_list_columns(result.elements)
    extraction_source = getattr(result, "extraction_source", None)

    unindexed_reason = None
    unindexed_detail = None
    if not result.elem_index_ok:
        # Диагностика #105: причина, по которой форма осталась без разметки.
        # Вызов не создаёт data_path и не изменяет result.
        info = classify_unindexed_form(form_dir, result)
        unindexed_reason = info.reason.value
        unindexed_detail = _sanitize_detail(info.detail, form_dir, form_ref)

    return {
        "form_dir": form_ref,
        "elem_index_ok": result.elem_index_ok,
        "extraction_source": extraction_source,
        "unindexed_reason": unindexed_reason,
        "unindexed_detail": unindexed_detail,
        "elements": len(result.elements),
        "legacy_list_columns": len(columns),
        "columns": [
            {
                "name": column.get("name"),
                "type": column.get("type"),
                "data_path": column.get("data_path"),
                "source": column.get("source"),
            }
            for column in columns
        ],
        "warnings": list(result.warnings),
    }


def _print_text(report: dict[str, Any]) -> None:
    print(f"Форма: {report['form_dir']}")
    print(f"elem_index_ok: {report['elem_index_ok']}")
    print(f"extraction_source: {report['extraction_source']!r}")
    print(f"Всего элементов: {report['elements']}")
    print(f"Колонок TabularField: {report['legacy_list_columns']}")

    columns = report["columns"]
    if columns:
        print("\nПодтверждённые привязки:")
        for column in columns:
            name = column["name"] or "<без имени>"
            data_path = column["data_path"] or "— (привязка не подтверждена)"
            print(f"  {name:<32} {data_path}")
    else:
        print("\nFallback #103 не вернул колонок для этой формы.")

    if report["unindexed_reason"]:
        print(f"\nПричина (#105): {report['unindexed_reason']}")
        print(f"  {report['unindexed_detail']}")

    if report["warnings"]:
        print("\nWarnings:")
        for warning in report["warnings"]:
            print(f"  - {warning}")


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Показать привязки колонок legacy ФормаСписка/ФормаВыбора, "
            "извлечённые fallback #103."
        )
    )
    parser.add_argument(
        "form_dir",
        type=Path,
        help="директория формы, содержащая *.elem.json и legacy *.json",
    )
    parser.add_argument(
        "--export-root",
        type=Path,
        default=None,
        help="корень выгрузки; ссылка на форму печатается относительно него",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="вывести машиночитаемый JSON",
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    form_dir = args.form_dir.expanduser().resolve()

    if not form_dir.is_dir():
        raise SystemExit(f"Директория формы не найдена: {args.form_dir}")

    root: Path | None = None
    if args.export_root is not None:
        root = args.export_root.expanduser().resolve()
        if not root.is_dir():
            raise SystemExit(f"Каталог выгрузки не найден: {args.export_root}")

    report = _build_report(form_dir, root)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        _print_text(report)

    return 0 if report["elem_index_ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
