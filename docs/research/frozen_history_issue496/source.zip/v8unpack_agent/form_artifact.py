"""Результат распаковки одной обычной формы.

``extraction_ok=False`` — это **не ошибка пайплайна**, а сигнал агенту: «по
этой форме видна только часть, не делай выводов о полноте». Без такого флага
агент будет молча работать на неполной информации.

``skd_extracted=True`` означает, что для внешнего отчёта (.erf) был успешно
выполнен второй шаг — извлечение запросов СКД в ``skd_queries.json``.
При ``skd_extracted=False`` агент видит только BSL-код модуля.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from v8unpack_agent.form_paths import form_paths

if TYPE_CHECKING:  # pragma: no cover - только для аннотаций
    from v8unpack_agent.form_identity import FormBinSource


@dataclass(frozen=True)
class FormArtifact:
    """Распакованная форма как артефакт пайплайна.

    Attributes
    ----------
    name:
        Имя формы (как в выгрузке), например ``"ФормаЭлемента"``.
    paths:
        Словарь путей к текстам формы (см. :func:`form_paths`):
        ``object_module``, ``ext_module``, ``metadata``.
    extraction_ok:
        ``True`` — распаковка полная; ``False`` — частичная (вложенные панели,
        нестандартные элементы, артефакты совместимости). При ``False`` поле
        ``extraction_warnings`` обязано быть непустым.
    extraction_warnings:
        Диагностические сообщения о неполноте распаковки. Пустой список при
        ``extraction_ok=True``.
    skd_extracted:
        Только для внешних отчётов (.erf). ``True`` — запросы схемы компоновки
        данных успешно извлечены в ``skd_queries.json`` рядом с распакованной
        директорией. ``False`` — агент видит только BSL модуля, СКД недоступна.
        Для обычных форм и внешних обработок (.epf) поле не актуально (False).
    elem_index_ok:
        Для обычных форм. ``True`` — структура формы (дерево элементов) успешно
        извлечена из ``elem.json`` в ``form_elements_index.json`` рядом с
        распакованной директорией. ``False`` — агент видит BSL-модуль формы,
        но не её структуру (типы элементов, вложенность, привязки). Best-effort:
        не влияет на ``extraction_ok``.
    """

    name: str
    paths: dict[str, Path]
    extraction_ok: bool
    extraction_warnings: list[str] = field(default_factory=list)
    skd_extracted: bool = False
    elem_index_ok: bool = False
    form_id: str = ""
    source: FormBinSource | None = None

    def __post_init__(self) -> None:
        if not self.extraction_ok and not self.extraction_warnings:
            raise ValueError(
                f"FormArtifact({self.name!r}) с extraction_ok=False обязан "
                "нести хотя бы одно предупреждение в extraction_warnings. "
                "Тихая частичная распаковка запрещена."
            )

    @classmethod
    def for_form(
        cls,
        unpacked_root: Path,
        form_name: str,
        *,
        extraction_ok: bool = True,
        extraction_warnings: list[str] | None = None,
        skd_extracted: bool = False,
        elem_index_ok: bool = False,
    ) -> FormArtifact:
        """Собрать артефакт по конвенции путей для формы ``form_name``."""
        return cls(
            name=form_name,
            paths=form_paths(unpacked_root, form_name),
            extraction_ok=extraction_ok,
            extraction_warnings=list(extraction_warnings or []),
            skd_extracted=skd_extracted,
            elem_index_ok=elem_index_ok,
        )

    @classmethod
    def for_source(
        cls,
        unpacked_root: Path,
        source: FormBinSource,
        *,
        extraction_ok: bool = True,
        extraction_warnings: list[str] | None = None,
        skd_extracted: bool = False,
        elem_index_ok: bool = False,
    ) -> FormArtifact:
        """Собрать артефакт по каноническому источнику формы (issue #226).

        В отличие от :meth:`for_form`, каталог результата строится по
        ``source.form_id``, поэтому одноимённые формы разных владельцев
        не пишут в один и тот же каталог.
        """
        return cls(
            name=source.form_name,
            paths=form_paths(unpacked_root, source.form_id),
            extraction_ok=extraction_ok,
            extraction_warnings=list(extraction_warnings or []),
            skd_extracted=skd_extracted,
            elem_index_ok=elem_index_ok,
            form_id=source.form_id,
            source=source,
        )
