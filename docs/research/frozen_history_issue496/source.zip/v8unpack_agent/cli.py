"""CLI production runner: владелец exit code и записи отчёта (issue #198).

Разделение ответственности
--------------------------

:mod:`v8unpack_agent.runner` — чистая библиотека без побочных эффектов.
Здесь сосредоточено всё, что взаимодействует с окружением: разбор аргументов,
запись post-run report и отображение состояния прогона в exit code.

Политика exit code
-------------------

=====  ==========================================================
Код    Условие
=====  ==========================================================
0      Все объекты ``complete``; отчёт записан.
2      Ошибка аргументов или ``export_root`` не каталог.
3      Degraded: есть ``partial``/``failed``, отчёт записан.
4      Управляемая фатальная ошибка пайплайна.
5      Ошибка записи отчёта.
6      Фатальная ошибка пайплайна и ошибка записи одновременно.
=====  ==========================================================

Degraded считается неуспешным завершением процесса: неполный LLM-контекст
не должен выглядеть как успех для вызывающей автоматизации.

Отчёт обязателен
----------------

``--report-path`` — обязательный аргумент без скрытого значения по умолчанию.
Прогон без записи отчёта невозможен: каталог-родитель должен существовать
заранее, иначе writer бросает ``RunReportWriteError`` и процесс завершается
кодом 5.

Диагностический вывод (issue #142)
----------------------------------

Сообщения в stderr проходят через
:func:`~v8unpack_agent._safe_paths.sanitize_diagnostic`. Непредвиденное
исключение после разбора аргументов не печатает traceback: выводится
нейтральный код ``internal_error`` с именем класса исключения, процесс
завершается кодом 4.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Sequence
from pathlib import Path

from v8unpack_agent._safe_paths import sanitize_diagnostic
from v8unpack_agent.run_report import RunReportWriteError, write_post_run_report
from v8unpack_agent.runner import (
    MODULE_GROUPS,
    RunOptions,
    RunOutcome,
    run_pipeline,
)

__all__ = [
    "EXIT_BAD_INPUT",
    "EXIT_DEGRADED",
    "EXIT_FATAL",
    "EXIT_FATAL_AND_WRITE_ERROR",
    "EXIT_OK",
    "EXIT_WRITE_ERROR",
    "main",
]

EXIT_OK = 0
EXIT_BAD_INPUT = 2
EXIT_DEGRADED = 3
EXIT_FATAL = 4
EXIT_WRITE_ERROR = 5
EXIT_FATAL_AND_WRITE_ERROR = 6

_PROGRAM = "v8unpack-agent-run"
_INTERNAL_ERROR_CODE = "internal_error"
_JSON_FLAG = "--json"
_DESCRIBE_FLAG = "--describe-cli"

#: Версия формы JSON-envelope режима ``--json`` (#258); см. docs/cli_json.md.
JSON_SCHEMA_VERSION = "1.0"
JSON_KIND = "v8unpack-agent-run.result"

#: Машинные коды ошибок envelope. Классифицируются по месту отказа и типу
#: исключения, а не по тексту сообщения.
ERROR_ARGUMENTS_INVALID = "arguments_invalid"
ERROR_EXPORT_ROOT_INVALID = "export_root_invalid"
ERROR_PIPELINE_FATAL = "pipeline_fatal"
ERROR_REPORT_WRITE_FAILED = "report_write_failed"
ERROR_PIPELINE_FATAL_AND_REPORT_WRITE_FAILED = "pipeline_fatal_and_report_write_failed"
ERROR_INTERNAL = _INTERNAL_ERROR_CODE

JSON_ERROR_CODES = (
    ERROR_ARGUMENTS_INVALID,
    ERROR_EXPORT_ROOT_INVALID,
    ERROR_INTERNAL,
    ERROR_PIPELINE_FATAL,
    ERROR_PIPELINE_FATAL_AND_REPORT_WRITE_FAILED,
    ERROR_REPORT_WRITE_FAILED,
)

_STATUS_BY_EXIT = {
    0: "ok",
    2: "bad_input",
    3: "degraded",
    4: "fatal",
    5: "write_error",
    6: "fatal_and_write_error",
}


def build_parser() -> argparse.ArgumentParser:
    """Собрать разборщик аргументов production-прогона."""
    parser = argparse.ArgumentParser(
        prog=_PROGRAM,
        description=(
            "Обработать распакованную выгрузку и записать post-run report."
        ),
    )
    parser.add_argument(
        "export_root",
        type=Path,
        help="корень уже распакованной выгрузки",
    )
    parser.add_argument(
        "--report-path",
        type=Path,
        required=True,
        help="путь к JSON-файлу отчёта; значения по умолчанию нет",
    )
    parser.add_argument(
        "--mode",
        choices=("config", "external"),
        default="config",
        help="режим сканирования форм",
    )
    parser.add_argument(
        "--skip-common-modules",
        action="store_true",
        help="не обнаруживать и не читать общие модули",
    )
    parser.add_argument(
        "--skip-skd",
        action="store_true",
        help="не извлекать артефакты СКД",
    )
    parser.add_argument(
        "--include-module-index",
        action="store_true",
        help="добавить в отчёт индекс BSL-модулей (issue #208)",
    )
    parser.add_argument(
        "--module-group",
        action="append",
        default=None,
        metavar="GROUP",
        help=(
            "включить только эту группу модулей, флаг повторяемый "
            f"({', '.join(MODULE_GROUPS)}); требует --include-module-index"
        ),
    )
    parser.add_argument(
        "--skip-module-group",
        action="append",
        default=None,
        metavar="GROUP",
        help=(
            "исключить группу модулей, флаг повторяемый; "
            "требует --include-module-index"
        ),
    )
    parser.add_argument(
        "--max-prompt-chars",
        type=int,
        default=-1,
        help="лимит длины промпт-фрагмента; -1 без ограничения",
    )
    parser.add_argument(
        "--representation",
        choices=("legacy", "framed"),
        default="legacy",
        help="режим представления данных выгрузки для LLM (ADR #457): legacy — прежний вывод, framed — обратимые блоки",
    )
    parser.add_argument(
        _JSON_FLAG,
        action="store_true",
        help=(
            "печатать в stdout один JSON-объект результата "
            "(schema_version 1.0) вместо текстовой сводки"
        ),
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Выполнить прогон и вернуть exit code без завершения процесса.

    Функция пригодна для вызова из тестов: она не вызывает ``sys.exit``,
    а ошибка разбора аргументов превращается в код возврата.
    """
    _configure_output()
    parser = build_parser()
    raw_args = list(sys.argv[1:] if argv is None else argv)
    if raw_args == [_DESCRIBE_FLAG]:
        # Интроспекция (#259) обрабатывается до argparse: --help не меняется,
        # выгрузка не читается, файлы не пишутся.
        from v8unpack_agent._cli_catalog import render_catalog

        sys.stdout.write(render_catalog())
        return EXIT_OK
    json_requested = _JSON_FLAG in raw_args

    try:
        args = parser.parse_args(raw_args)
        module_groups = _resolve_module_groups(parser, args)
    except SystemExit as exc:
        code = _exit_code_from_system_exit(exc)
        if json_requested and code != EXIT_OK:
            _emit_json(code, error_code=ERROR_ARGUMENTS_INVALID)
        return code

    json_mode = bool(args.json)
    export_root = Path(args.export_root)
    if not export_root.is_dir():
        print(
            f"{_PROGRAM}: корень выгрузки не найден или не является каталогом: "
            f"{export_root.name}",
            file=sys.stderr,
        )
        if json_mode:
            _emit_json(EXIT_BAD_INPUT, error_code=ERROR_EXPORT_ROOT_INVALID)
        return EXIT_BAD_INPUT

    options = RunOptions(
        export_root=export_root,
        mode=args.mode,
        include_common_modules=not args.skip_common_modules,
        include_skd=not args.skip_skd,
        include_module_index=args.include_module_index,
        module_groups=module_groups,
        max_prompt_chars=args.max_prompt_chars,
        representation=args.representation,
    )

    try:
        outcome = run_pipeline(options)
        report_path = Path(args.report_path)
        write_error = _write_report(outcome, report_path)

        code = _resolve_exit_code(outcome, write_error=write_error)
        if json_mode:
            _print_fatal(outcome)
            _emit_json(
                code,
                error_code=_error_code_for(code),
                data=_json_data(outcome, report_path, write_error=write_error),
            )
        else:
            _print_summary(outcome, write_error=write_error)
        return code
    except Exception as exc:  # noqa: BLE001 — внешняя fail-closed граница CLI
        # str/repr исключения не печатается: в нём может быть путь.
        print(
            f"{_PROGRAM}: внутренняя ошибка: {_INTERNAL_ERROR_CODE} "
            f"({type(exc).__name__})",
            file=sys.stderr,
        )
        if json_mode:
            _emit_json(EXIT_FATAL, error_code=ERROR_INTERNAL)
        return EXIT_FATAL


def _resolve_module_groups(
    parser: argparse.ArgumentParser,
    args: argparse.Namespace,
) -> tuple[str, ...] | None:
    """Свести флаги групп к итоговому набору (issue #346).

    Любая ошибка использования даёт ``parser.error`` (код 2, отчёт не
    создаётся). Введённые значения в сообщении не повторяются: в них может
    оказаться путь.
    """
    include = args.module_group
    skip = args.skip_module_group
    if include is None and skip is None:
        return None
    if not args.include_module_index:
        parser.error("группы модулей требуют --include-module-index")
    if include is not None and skip is not None:
        parser.error("--module-group и --skip-module-group несовместимы")
    names = include if include is not None else skip
    if any(name not in MODULE_GROUPS for name in names):
        parser.error(
            "неизвестная группа модулей; допустимые: " + ", ".join(MODULE_GROUPS)
        )
    chosen = frozenset(names)
    if include is not None:
        return tuple(name for name in MODULE_GROUPS if name in chosen)
    rest = tuple(name for name in MODULE_GROUPS if name not in chosen)
    if not rest:
        parser.error("исключены все группы модулей")
    return rest


def _write_report(outcome: RunOutcome, report_path: Path) -> RunReportWriteError | None:
    """Записать отчёт; вернуть ошибку записи, если она произошла."""
    try:
        write_post_run_report(outcome.report, report_path)
    except RunReportWriteError as exc:
        print(
            f"{_PROGRAM}: не удалось записать отчёт: {sanitize_diagnostic(exc)}",
            file=sys.stderr,
        )
        return exc
    return None


def _resolve_exit_code(
    outcome: RunOutcome,
    *,
    write_error: RunReportWriteError | None,
) -> int:
    """Отобразить состояние прогона в exit code.

    Одновременные фатальная ошибка и отказ записи получают отдельный код:
    иначе вызывающая автоматизация не смогла бы отличить единичный отказ
    от полной потери наблюдаемости.
    """
    if not outcome.completed and write_error is not None:
        return EXIT_FATAL_AND_WRITE_ERROR
    if write_error is not None:
        return EXIT_WRITE_ERROR
    if not outcome.completed:
        return EXIT_FATAL
    if outcome.degraded:
        return EXIT_DEGRADED
    return EXIT_OK


def _print_summary(
    outcome: RunOutcome,
    *,
    write_error: RunReportWriteError | None,
) -> None:
    """Напечатать краткую сводку без путей и доменных данных."""
    summary = outcome.report.summary
    print(
        "обнаружено: "
        f"{summary.found}, complete: {summary.complete}, "
        f"partial: {summary.partial}, failed: {summary.failed}, "
        f"excluded: {summary.excluded}"
    )
    print(f"промпт-символов: {outcome.prompt_chars}")
    print(f"предупреждений сканера: {len(outcome.scan_warnings)}")

    _print_fatal(outcome)

    if write_error is None:
        print("отчёт записан")


def _print_fatal(outcome: RunOutcome) -> None:
    """Напечатать в stderr код фатальной ошибки прогона, если она есть."""
    fatal_error = outcome.report.fatal_error
    if fatal_error is not None:
        print(
            f"фатальная ошибка: {fatal_error.reason_code} "
            f"({fatal_error.error_type})",
            file=sys.stderr,
        )


def _error_code_for(exit_code: int) -> str | None:
    """Машинный код ошибки по уже вычисленному exit code прогона."""
    return {
        EXIT_FATAL: ERROR_PIPELINE_FATAL,
        EXIT_WRITE_ERROR: ERROR_REPORT_WRITE_FAILED,
        EXIT_FATAL_AND_WRITE_ERROR: ERROR_PIPELINE_FATAL_AND_REPORT_WRITE_FAILED,
    }.get(exit_code)


def _json_data(
    outcome: RunOutcome,
    report_path: Path,
    *,
    write_error: RunReportWriteError | None,
) -> dict[str, object]:
    """Данные прогона для envelope: счётчики и метаданные без путей."""
    summary = outcome.report.summary
    fatal_error = outcome.report.fatal_error
    return {
        "completed": outcome.completed,
        "degraded": outcome.degraded,
        "summary": {
            "found": summary.found,
            "complete": summary.complete,
            "partial": summary.partial,
            "failed": summary.failed,
            "excluded": summary.excluded,
        },
        "prompt_chars": outcome.prompt_chars,
        "scan_warnings": len(outcome.scan_warnings),
        "fatal_error": (
            None
            if fatal_error is None
            else {
                "reason_code": fatal_error.reason_code,
                "error_type": fatal_error.error_type,
            }
        ),
        "report": {
            "file_name": report_path.name,
            "written": write_error is None,
            "schema_version": outcome.report.schema_version,
        },
    }


def _emit_json(
    exit_code: int,
    *,
    error_code: str | None,
    data: dict[str, object] | None = None,
) -> None:
    """Напечатать в stdout ровно один JSON-объект envelope."""
    envelope = {
        "schema_version": JSON_SCHEMA_VERSION,
        "kind": JSON_KIND,
        "ok": exit_code == EXIT_OK,
        "status": _STATUS_BY_EXIT.get(exit_code, "fatal"),
        "exit_code": exit_code,
        "error": None if error_code is None else {"code": error_code},
        "data": data,
    }
    sys.stdout.write(
        json.dumps(envelope, ensure_ascii=False, sort_keys=True) + "\n"
    )


def _exit_code_from_system_exit(exc: SystemExit) -> int:
    """Преобразовать ``SystemExit`` argparse в целочисленный код.

    ``--help`` и ``--version`` завершаются кодом 0, ошибка аргументов — кодом 2.
    """
    code = exc.code
    if code is None:
        return EXIT_OK
    if isinstance(code, int):
        return code
    return EXIT_BAD_INPUT


def _configure_output() -> None:
    """Перевести стандартные потоки в UTF-8 для Windows-консоли и CI."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            reconfigure(encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
